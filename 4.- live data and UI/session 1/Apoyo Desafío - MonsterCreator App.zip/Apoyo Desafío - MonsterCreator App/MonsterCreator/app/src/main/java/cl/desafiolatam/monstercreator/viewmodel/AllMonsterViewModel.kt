package cl.desafiolatam.monstercreator.viewmodel

/**
 * Created by Cristian Vidal on 2019-10-02.
 */
class AllMonsterViewModel {
}