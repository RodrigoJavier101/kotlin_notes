package cl.desafiolatam.monstercreator.model

/**
 * Created by Cristian Vidal on 2019-10-02.
 */
data class MonsterImage(val drawable: Int)