package cl.desafiolatam.monstercreator.model

/**
 * Created by Cristian Vidal on 2019-09-26.
 */
data class MonsterAttributes(
    val intelligence: Int = 0,
    val ugliness: Int = 0,
    val evilness: Int = 0
)
