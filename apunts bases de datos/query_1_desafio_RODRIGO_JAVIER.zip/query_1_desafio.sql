
create table editorial(
codigo int, 
nombre varchar(30),
primary key (codigo)
);


create table libro(
codigo int, 
titulo varchar(30),
codigoEditorial int,
primary key (codigo), 
foreign key (codigoEditorial) references libro(codigo)
);


insert into editorial(codigo, nombre) values (1, 'anaya');
insert into editorial(codigo, nombre) values (2, 'andina');
insert into editorial(codigo, nombre) values (3, 'S M');
insert into editorial(codigo, nombre) values (4, 'Iberlibros');

insert into libro(codigo, titulo, codigoEditorial) values(1,'don quijote de la mancha parte-I', 1);
insert into libro(codigo,titulo, codigoEditorial) values(2,'don quijote de la mancha parte-II', 1);
insert into libro(codigo,titulo, codigoEditorial) values (3,'el principito', 2);
insert into libro(codigo,titulo, codigoEditorial) values (4,'el principe', 3);
insert into libro(codigo,titulo, codigoEditorial) values(5,'diplomacia', 4);



alter table libro add column autor;
update libro set autor = 'miguel de cervantes y saavedra' where codigo = 1 and codigo = 2;
update libro set autor = 'kissinger' where codigo = 4;
update libro set autor = 'antoine de saint exupery' where codigo = 2;
update libro set autor = 'maquiavelo' where codigo = 3;

insert into libro (codigo, titulo, autor) values (5, 'la negra ester', 'papichulo');
insert into libro (codigo, titulo, autor) values (5, 'papelucho', 'letelier?');

delete from libro where codigoeditorial = 1;

update editorial set nombre = IberLibro where nombre = Andina;

create table usuarios(
codigo int,
nombre varchar(30), 
apellido varchar(30),
telefono varchar(30),
primary key (codigo)
);

create table prestamos(
codigo int, 
codigoLibro int, 
codigoUsuario int, 
fechaPrestamo date,
primary key (codigo),
foreign key (codigoLibro) references libro(codigo),
foreign key (codigoUsuario) references usuarios(usuarios)
);

insert into usuarios (codigo, nombre, apellido, telefono) values (1, 'jos�','soto','98347756');
insert into usuarios (codigo, nombre, apellido, telefono) values (2, 'miguel','gomez','94845537');
insert into usuarios (codigo, nombre, apellido, telefono) values (3, 'sara','avenda�o','93345455');
insert into usuarios (codigo, nombre, apellido, telefono) values (4, 'jaime','carrasco','92223453'); 

insert into prestamos (codigo, codigoLibro, codigoUsuario, fechaPrestamo) values (1,3 ,1,'2019-01-10');
insert into prestamos (codigo, codigoLibro, codigoUsuario, fechaPrestamo) values (2,5 ,2,'2019-02-10');
insert into prestamos (codigo, codigoLibro, codigoUsuario, fechaPrestamo) values (3,3 ,3,'2019-01-20');
insert into prestamos (codigo, codigoLibro, codigoUsuario, fechaPrestamo) values (4,1 ,4,'2019-10-10');
insert into prestamos (codigo, codigoLibro, codigoUsuario, fechaPrestamo) values (5,2 ,4,'2019-01-11');





