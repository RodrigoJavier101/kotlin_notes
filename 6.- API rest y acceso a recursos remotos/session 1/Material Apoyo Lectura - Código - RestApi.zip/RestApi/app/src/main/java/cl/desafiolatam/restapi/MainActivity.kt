package cl.desafiolatam.restapi

import android.app.Dialog
import android.graphics.Color
import android.os.Bundle
import android.support.design.widget.CoordinatorLayout
import android.support.design.widget.FloatingActionButton
import android.support.design.widget.Snackbar
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.helper.ItemTouchHelper
import android.util.Log
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import cl.desafiolatam.restapi.adapters.CustomAdapter
import cl.desafiolatam.restapi.pojo.Post
import cl.desafiolatam.restapi.utils.RetrofitClient
import cl.desafiolatam.restapi.utils.UIHelper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import java.util.ArrayList

class MainActivity : AppCompatActivity(), SwipeRefreshLayout.OnRefreshListener {


    internal lateinit var recyclerView: RecyclerView
    internal lateinit var mAdapter: CustomAdapter
    internal lateinit var coordinatorLayout: CoordinatorLayout
    private lateinit var swipeRefreshLayout : SwipeRefreshLayout

    override fun onRefresh() {
        //WE CHECK INTERNET CONNECTION
        try{
            loadApiData()
        }catch(e: Exception){
            Toast.makeText(this, "Ocurrió un error, verifica tu conexión a internet", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        swipeRefreshLayout.setOnRefreshListener(this)

        recyclerView = findViewById(R.id.recyclerView)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        val mFab = findViewById<FloatingActionButton>(R.id.fab)
        mFab.setOnClickListener {
            showDialog()
        }

        loadApiData()

    }

    private fun loadApiData(){
        val service = RetrofitClient.retrofitInstance()
        val call = service.getAllPosts()

        //Async
        call.enqueue(object : Callback<ArrayList<Post>> {
            override fun onResponse(call: Call<ArrayList<Post>>, response: Response<ArrayList<Post>>) {

                val postsFromApi = response.body()

                if (postsFromApi != null) {
                    mAdapter = CustomAdapter(postsFromApi)
                    recyclerView.adapter = mAdapter

                    enableSwipeToDeleteAndUndo()
                }
            }

            override fun onFailure(call: Call<ArrayList<Post>>, t: Throwable) {
                Log.d("MAIN", "Error: "+t)
                Toast.makeText(
                    applicationContext,
                    "Error: no pudimos recuperar los posts desde el api",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        swipeRefreshLayout.isRefreshing = false
    }

   fun addNewPostOnApi(post: Post){
        val service = RetrofitClient.retrofitInstance()
        val call = service.createNewPost(post)
        //Async
        call.enqueue(object : Callback<Post> {
            override fun onResponse(call: Call<Post>, response: Response<Post>) {

                val responseCode = response.code()
                if(responseCode == 200 || responseCode == 201){
                    Toast.makeText(applicationContext,
                        "Post creado exitosamente. Recuerda esto solo es una respuesta desde el servidor del api público, tus datos no serán almacenados. ",Toast.LENGTH_LONG).show()
                    Toast.makeText(applicationContext,
                        "Título: " +response.body()!!.title+ ", " +
                                "Descripción: "+response.body()!!.body+", " +
                                "UserId: "+response.body()!!.userId, Toast.LENGTH_LONG).show()
                }else{
                    Toast.makeText(applicationContext, "Error al crear post. Código: "+responseCode, Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<Post>, t: Throwable) {
                Log.d("MAIN", "Error: "+t)
                Toast.makeText(
                    applicationContext,
                    "Error: no pudimos recuperar los posts desde el api",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
   }


    private fun enableSwipeToDeleteAndUndo() {
        val swipeToDeleteCallback = object : UIHelper(this) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, i: Int) {


                val position = viewHolder.adapterPosition
                val item = mAdapter.data.get(position)

                //ELIMINAMOS DEL SERVIDOR EL POST (FAKE)
                deletePostFromApi(item.id)
                mAdapter.removeItem(position)


                val snackbar = Snackbar
                    .make(coordinatorLayout, "El post ha sido eliminado de la lista", Snackbar.LENGTH_LONG)
                snackbar.setAction("DESHACER") {
                    mAdapter.restoreItem(item, position)
                    recyclerView.scrollToPosition(position)
                }

                snackbar.setActionTextColor(Color.YELLOW)
                snackbar.setDuration(12000)
                snackbar.show()

            }
        }

        val itemTouchhelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchhelper.attachToRecyclerView(recyclerView)
    }


    private fun showDialog(){

        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.new_post_dialog)
        val title = dialog .findViewById(R.id.titleJsonParam) as TextView
        val body = dialog .findViewById(R.id.bodyJsonParam) as TextView
        val userId = dialog .findViewById(R.id.userIdJsonParam) as TextView
        val btnSend = dialog .findViewById(R.id.btnSend) as Button

        btnSend.setOnClickListener {
            val post = Post()

            try {
                post.title = title.text.toString()
                post.body = body.text.toString()
                val userIdStr = userId.text.toString()
                post.userId = userIdStr.toInt()
                addNewPostOnApi(post)
            }catch (e: Exception){
                Log.d("MAIN", "Error al crear post",e)
            }
            dialog .dismiss()
        }
        dialog .show()

    }

    private fun deletePostFromApi(postId: Int?){
        val service = RetrofitClient.retrofitInstance()
        val call = service.deletePost(postId)
        call.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {

                if(response.code() == 200) {
                    Toast.makeText(
                        applicationContext,
                        "Se ha eliminado correctamente el post en el api. Código respuesta de servidor: "+ response.code(), Toast.LENGTH_LONG).show()

                    Toast.makeText(applicationContext, "Recuerda, nuestra api sólo facilita métodos http públicos para REST. Esta operación no elimina datos reales.",
                    Toast.LENGTH_LONG
                    ).show()

                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                // handle failure
                Toast.makeText(applicationContext, "Ocurrió un error borrando el post en el api. "+t, Toast.LENGTH_LONG).show()
            }
        })
    }
}
