package cl.desafiolatam.restapi.adapters

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import cl.desafiolatam.restapi.R
import cl.desafiolatam.restapi.pojo.Post
import com.squareup.picasso.Picasso

import java.util.ArrayList

class CustomAdapter(val data: ArrayList<Post>) : RecyclerView.Adapter<CustomAdapter.CustomViewHolder>() {

    inner class CustomViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mTitle: TextView = itemView.findViewById(R.id.txtTitle)
        val mImgPost: ImageView = itemView.findViewById(R.id.imgPost)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.posts_list, parent, false)
        return CustomViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {

        holder.mTitle.text = data[position].title
        Picasso.get().load("https://cdn.pixabay.com/photo/2014/03/25/16/54/envelope-297570_960_720.png").into(holder.mImgPost)
        Picasso.get().setIndicatorsEnabled(true)
    }

    override fun getItemCount(): Int {
        return data.size
    }


    fun removeItem(position: Int) {
        data.removeAt(position)
        notifyItemRemoved(position)
    }

    fun restoreItem(item: Post, position: Int) {
        data.add(position, item)
        notifyItemInserted(position)
    }
}