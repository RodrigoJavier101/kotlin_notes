package cl.desafiolatam.restapi.utils

import cl.desafiolatam.restapi.pojo.Post
import retrofit2.Call
import retrofit2.http.*

import java.util.ArrayList

interface Api {
    @GET("/posts")
    fun getAllPosts(): Call<ArrayList<Post>>

    @Headers("Content-Type: application/json; charset=UTF-8")
    @POST("/posts")
    fun createNewPost(@Body post: Post): Call<Post>

    @DELETE("/posts/{postId}")
    fun deletePost(@Path("postId") postId: Int?): Call<Void>

}
